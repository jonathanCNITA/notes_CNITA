#!/bin/sh
echo apache2 will start soon
service apache2 start
